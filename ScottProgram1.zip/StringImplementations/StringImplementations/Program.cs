﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace StringImplementations
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader file = new StreamReader("c:/tmp/all-names.txt");
            StringFunctionsDef sfd = new StringFunctionsDef(1000);

            while (!file.EndOfStream)
            {
                sfd.Add_String(file.ReadLine());
            }
            Console.WriteLine("Compares: {0}, Moves: {1}", sfd.numberComp, sfd.numberMoves);
            string[] result = sfd.Insert_String(2, "Andrew");
            file.Close();
            File.WriteAllLines("c:/tmp/all-names.txt", result);
            Console.Read();
        }
    }
}
